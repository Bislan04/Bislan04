public class Fillin extends Question {
	Fillin() {

	}

	public String toString() {
		return super.getDescription();
	}
}