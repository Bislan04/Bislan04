public class InvalidQuizFormatException extends Exception {
    public InvalidQuizFormatException(String var) {
        super(var);
    }
}
