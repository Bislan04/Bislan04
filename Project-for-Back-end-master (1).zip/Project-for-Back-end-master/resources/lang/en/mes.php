<?php
	return[
		//heading
		"home" => "Home",
		"service" => "Service",
		"beetv" => "BeeTV",
		"plan" => "Plan",
		"contact" => "Contact",
		"login" => "Login",
		"register" => "Register",
		"user" => "User",
		"logout" => "OLogout",
		//home
		"beeline" => "Beeline",
		"welcome" => "Welcome to Beeline",
		"lorem1" => "Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque, vero repellendus! Accusantium doloremque placeat eaque eligendi quaerat? Cupiditate, quae corrupti?",
		//beeTV
		"start" => "get Started",
		"hdrip" => "HDRip",
		"snyder" => "SnyderCUT (2021) Starting from March only in cinemas HD quality",
		"mortal" => "Mortal Combat (2021) Starting from April only in cinemas HD quality",
		"kong" => "Kong VS Godzilla (2021) Starting from March only in cinemas HD quality",
		"mission" => "Mission Impossible (2021) Starting from April only in cinemas HD quality",
		"shazam" => "Shazam (2019) Starting from September only in cinemas HD quality",
		"antman" => "Ant Man (2015) Full Movie in Russia with English subtitles | HDRip 1080p HD",
		"birds" => "Birds Of Prey (2019) Full Movie in Russia with English subtitles | HDRip 1080p HD",
		"cpm" => "Captain Marvel (2019) Full Movie in Russia with English subtitles | HDRip 1080p HD",
		"single" => "Single Reinger (2012) Full Movie in Russia with English subtitles | HDRip 1080p HD",
		"spider" => "Spider Man (2021) Full Movie in Russia with English subtitles | HDRip 1080p HD",
		"fast" => "Fast and Furious (2019) Starting from September only in cinemas HD quality",
		"joker" => "Joker (2019) Starting from September only in cinemas HD quality",
		"learn" => "Learn more",
		//service
		"balans" => "top up balans",
		"lorem2" => "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Error esse modi enim impedit vel dignissimos adipisci neque cum est commodi.",
		"go" => "go to Beeline",
		"tarif" => "Yarkayia 7ya",
		"transfer" => "Transfer and Payments",
		"enter" => "Entertaiment",
		"replace" => "Replace sim card",
		//plan
		"basic" => "basic",
		"mo" => "mo",
		"10gb" => "10 GB per month",
		"100min" => "100 minutes",
		"100sms" => "100 sms",
		"5sub" => "5 Subdomains",
		"check" => "Check Out",

		"standard" => "Standard",
		"20gb" => "20 GB per month",
		"200min" => "200 minutes",
		"200sms" => "200 sms",
		"15sub" => "15 Subdomains",
		
		"premium" => "Premium",
		"40gb" => "40 GB per month",
		"400min" => "400 minutes",
		"400sms" => "400 sms",
		"25sub" => "25 Subdomains",

		//contack us
		"contact1" => "contact us for latest updates",
		"lorem3" => "Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum mollitia excepturi hic doloremque laboriosam. Fugiat adipisci provident ullam magni quia?",
		"alma" => "Almaty, Qazaqstan 400104.",

		"n" => "Name",
		"e" => "Your Email",
		"ph" => "Phone number",
		"ms" => "Message",
		
		///foooteer
		"chose" => "why choose us?",	
		"lorem4" => "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab, illum voluptatum. Unde, consequuntur at. Molestias culpa suscipit explicabo possimus iusto?",
		"quick" => "Quick Links",
		"news" => "Newsletter",
		"subs" => "subscribe us for latest updates",
		"create" => "created by",
		"be" => "beeline center",
		"all" => "all rights reserved.",
		"subscribe" => "Subscribe"
	];
?>
