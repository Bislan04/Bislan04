# Beeline site demo
I created a simple website about Beeline in this site, which contains my home , services, BiiTV, plan, contacts and login .In Strnitsedomo you can see the main page , And BiiTV has a selection of new and old movies , and the services are those that we are able to present to you, and the contact can be contacted with dreams via email we will read and respond, and the plan contains our best rates with improved conditions, f login can register, and then there is a konpka user who can upload images for use.
![image](https://user-images.githubusercontent.com/75586686/116011513-41195480-a647-11eb-8ae3-acb8bc092e9f.png)

![image](https://user-images.githubusercontent.com/75586686/123956968-147a1400-d9cd-11eb-8ebf-a12de0050a8a.png)

![image](https://user-images.githubusercontent.com/75586686/123957031-278ce400-d9cd-11eb-8b78-ffdf27efe6cd.png)

![image](https://user-images.githubusercontent.com/75586686/123957117-3d9aa480-d9cd-11eb-9107-70aab3b22f8b.png)

![image](https://user-images.githubusercontent.com/75586686/123958742-3aa0b380-d9cf-11eb-8f46-f77f8928da35.png)

![image](https://user-images.githubusercontent.com/75586686/123958786-4ab89300-d9cf-11eb-989d-6d04ffaba919.png)

![image](https://user-images.githubusercontent.com/75586686/123958873-602dbd00-d9cf-11eb-813b-83becd8ee881.png)
----
![image](https://user-images.githubusercontent.com/75586686/123958981-79cf0480-d9cf-11eb-9ab5-a4306d1ee700.png)

![image](https://user-images.githubusercontent.com/75586686/123959068-910df200-d9cf-11eb-86a3-992dec638805.png)
---

