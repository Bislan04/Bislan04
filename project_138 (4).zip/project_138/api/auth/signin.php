<?php
    include "../../config/db.php";
    include "../../config/baseurl.php";
    if(isset($_POST["email"] , $_POST["password"])){
        $email = $_POST["email"];
        $password = $_POST["password"];
        $query = mysqli_query($con , "SELECT * FROM users WHERE email = '$email' ");
        $hash = sha1($password);
        $row = mysqli_fetch_assoc($query);
        if($hash != $row["password"]){
            header("Location: $BASE_URL/login.php?error=4");
            exit();
        }
        session_start();
        $_SESSION["nickname"] = $row["nickname"];
        $_SESSION["id"] = $row["id"];
        $nickname = $row["nickname"];
        header("Location:$BASE_URL/profile.php?nickname=$nickname");
    }