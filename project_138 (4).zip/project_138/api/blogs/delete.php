<?php
    include "../../config/db.php";
    include "../../config/baseurl.php";
    $id = $_GET["id"];
    mysqli_query($con , "DELETE FROM blogs WHERE id = '$id' ");
    session_start();
    $nick = $_SESSION["nickname"];
    header("Location: $BASE_URL/profile.php?nickname=$nick");
