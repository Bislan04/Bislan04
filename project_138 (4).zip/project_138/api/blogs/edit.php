<?php
    include "../../config/db.php";
    include "../../config/baseurl.php";

    if(isset($_POST["title"] , 
             $_POST["description"],
             $_POST["category_id"],
             $_POST["blog_id"]) &&
        strlen($_POST["title"]) > 0 &&
        strlen($_POST["description"]) > 0 &&
        intval($_POST["category_id"]))
    {
        $title = $_POST["title"];
        $description = $_POST["description"];
        $categ_id = $_POST["category_id"];
        $blog_id = $_POST["blog_id"];
        session_start();
        $author_id = $_SESSION["id"];
        if(isset($_FILES["image"]) && isset($_FILES["image"]["name"]) 
           && strlen($_FILES["image"]["name"]) > 0){
            $check = mysqli_query($con , "SELECT * FROM blogs WHERE id = '$id'");
            $a = mysqli_fetch_assoc($check);
            if($a["image"] != NULL){
                $old_path = $a["image"];
                unlink($old_path);
            }
            $ext = end(explode("." , $_FILES["image"]["name"]));
            $image_name = time().".".$ext;
            move_uploaded_file($_FILES["image"]["tmp_name"] , "../../images/blogs/$image_name");
            $path = "images/blogs/$image_name";
            mysqli_query($con , "UPDATE blogs SET title = '$title' , description = '$description', 
            image = '$path' , category_id = '$categ_id' WHERE id = '$blog_id'");
        }else{
            mysqli_query($con , "UPDATE blogs SET title = '$title' , description = '$description', 
            category_id = '$categ_id' WHERE id = '$blog_id'");
        }
        $nick = $_SESSION["nickname"];
        header("Location:$BASE_URL/profile.php?nickname=$nick");
    }else{
        $blog_id = $_POST["blog_id"];
        header("Location:$BASE_URL/editblog.php?error=6&id=$blog_id");
    }