<?php
    include "../../config/db.php";
    include "../../config/baseurl.php";

    if(isset($_POST["title"] , 
             $_POST["description"],
             $_POST["category_id"]) &&
        strlen($_POST["title"]) > 0 &&
        strlen($_POST["description"]) > 0 &&
        intval($_POST["category_id"]))
    {
        $title = $_POST["title"];
        $description = $_POST["description"];
        $categ_id = $_POST["category_id"];
        session_start();
        $author_id = $_SESSION["id"];
        if(isset($_FILES["image"]) && isset($_FILES["image"]["name"]) 
           && strlen($_FILES["image"]["name"]) > 0){
            
            // my.asd.jpeg
            // [my ,asd , jpeg]
            $ext = end(explode("." , $_FILES["image"]["name"]));
            $image_name = time().".".$ext;
            move_uploaded_file($_FILES["image"]["tmp_name"] , "../../images/blogs/$image_name");
            $path = "images/blogs/$image_name";
            mysqli_query($con , "INSERT INTO blogs (title , description , image , category_id , author_id)
            VALUES ('$title' , '$description' , '$path' , '$categ_id' , '$author_id')");
        }else{
            mysqli_query($con , "INSERT INTO blogs (title , description  , category_id , author_id)
            VALUES ('$title' , '$description' , '$categ_id' , '$author_id')");
        }
        $nick = $_SESSION["nickname"];
        header("Location:$BASE_URL/profile.php?nickname=$nick");
    }else{
        header("Location:$BASE_URL/newblog.php?error=5");
    }