
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Редактировать блог</title>
	<?php include "views/head.php" ?>
</head>
<body>
<?php include "views/header.php" ?>
	<section class="container page">
		<div class="page-block">
			<div class="page-header">
				<h2>Редактировать блог</h2>
			</div>
			<form class="form" action="api/blogs/edit.php" method="POST" enctype="multipart/form-data">
				<?php
					$id = $_GET["id"];
					$query = mysqli_query($con , "SELECT * FROM blogs WHERE id = '$id' ");
					$row = mysqli_fetch_assoc($query);
				?>
				<input type="hidden" value="<?=$id?>" name="blog_id">
				<fieldset class="fieldset">
					<input class="input" type="text" name="title" placeholder="Заголовок" value="<?=$row["title"]?>">
				</fieldset>

				<fieldset class="fieldset">
				<select name="category_id" id="" class="input">
					<?php
						$categories = mysqli_query($con , "SELECT * FROM categories");
						while($categ = mysqli_fetch_assoc($categories)){
							if($categ["id"] == $row["category_id"]){
					?>
						<option value="<?=$categ["id"]?>" selected><?=$categ["name"]?></option>
					<?php }else{ ?>
						<option value="<?=$categ["id"]?>"><?=$categ["name"]?></option>
					<?php
						}
					}
					?>
				</select>
			</fieldset class="fieldset">

				<fieldset class="fieldset">
					<button class="button button-yellow input-file">
						<input type="file" name="image">	
						Выберите картинку
					</button>
				</fieldset>
					
				<fieldset class="fieldset">
					<textarea class="input input-textarea" name="description" id="" cols="30" rows="10" placeholder="Описание"><?=$row["description"]?></textarea>
				</fieldset>
				<fieldset class="fieldset">
					<button class="button" type="submit">Сохранить</button>
				</fieldset>
			</form>

			
				<!-- <p class="text-danger"> Заголовок и Описание не могут быть пустыми!</p> -->



		</div>

	</section>
	
	

	
	
</body>
</html>
